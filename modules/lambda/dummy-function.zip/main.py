def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': 'This method is not implemented yet but don\'t be afraid, it will work soon!'
    }
